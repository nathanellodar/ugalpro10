def hitung_nilai(daftar_nilai, n):
    daftar_nama = []
    nilai = []
    for panggil, isi in daftar_nilai.items():
        isi.sort()
        nama = panggil
        daftar_nama.append(nama)
        daftar_nilai = isi  
        akan = daftar_nilai[-1] + daftar_nilai[-2]     
        rata_rata = akan/n
        nilai.append(rata_rata)
    huruf_depan = lambda a: a[0]
    daftar_nama.sort(key=huruf_depan)
    nilai.sort
    index = 0
    for panggil in range(len(daftar_nama)):
        print(f'{daftar_nama[index]} = %f' % nilai[index])
        index += 1


daftar_nilai = {
    'Udin' : [65, 74, 56, 80, 82, 94],
    'Atun' : [98, 84, 82, 88],
    'Tejo' : [85, 86]
}
n =2
hitung_nilai(daftar_nilai, n)