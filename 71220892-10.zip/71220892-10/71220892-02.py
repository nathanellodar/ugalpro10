def tanpa_tigabelas(daftar_angka):
    total = 0
    if len(daftar_angka) == 0:
        return ("Isi list kosong")
    else:
        for panggil in range(len(daftar_angka)):
            if daftar_angka[panggil] != 13:
                total += daftar_angka[panggil]
            else:
                break
        return total
print(tanpa_tigabelas([2, 4, 1, 3, 13, 8]))
