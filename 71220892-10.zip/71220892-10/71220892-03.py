def keliling_segitiga(abc):
    nama = ''
    daftar = []
    for panggil in abc:
        nama += panggil
        daftar.append(panggil)
    a = abc[daftar[0]]
    b = abc[daftar[1]]
    c = abc[daftar[2]]
    ab = ((a[0] - b[0])**2 + (a[1] - b[1])**2)**0.5
    bc = ((b[0] - c[0])**2 + (b[1] - c[1])**2)**0.5
    ac = ((a[0] - c[0])**2 + (a[1] - c[1])**2)**0.5
    total = ab + bc + ac
    print(f'Segitiga {nama} memiliki keliling {total:.4f}')
keliling_segitiga({'J' : [1,3], 'K' : [4,5] , 'L' : [3,0]})